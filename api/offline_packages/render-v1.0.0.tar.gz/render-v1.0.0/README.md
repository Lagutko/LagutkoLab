Render
======
Render a Jinja2 template using CLI options, environment variables, or YAML
files as input.
